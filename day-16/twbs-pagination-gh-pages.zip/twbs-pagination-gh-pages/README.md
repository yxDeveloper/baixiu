An jQuery pagination plugin (bootstrap powered).

[Documentation](http://esimakin.github.io/twbs-pagination/)
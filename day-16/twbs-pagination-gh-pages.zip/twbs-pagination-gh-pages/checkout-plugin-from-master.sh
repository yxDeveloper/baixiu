#!/usr/bin/env bash

git checkout master -- jquery.twbsPagination.js
git mv -f jquery.twbsPagination.js js/jquery.twbsPagination.js
git add js/jquery.twbsPagination.js